

아나콘다를 설치하여 아나콘다 프롬프트에서 가상환경을 만들고 requirements.txt 파일안의 모듈내용들을 
pip install -r requirements.txt 명령어로 설치합니다.
아나콘다 프롬프트에서 pyqtGUI.py 파일과 polybot.py 파일이 있는 경로로 들어가 
python pyqtGUI.py 또는 python polybot.py 명령어를 입력하여 gui를 띄우고 opencv안에서 젓가락판별을 합니다