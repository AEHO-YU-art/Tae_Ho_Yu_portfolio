import cv2
import math
import numpy as np
import mediapipe as mp
from PIL import Image, ImageDraw, ImageFont
from ctypes import cast, POINTER
#pip install comtypes
from comtypes import CLSCTX_ALL
#pip install pycaw
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
# AI Chopstick
import torch
import torch.nn as nn
from chopstick import AIchopstick

# 젓가락질 정상 인식 인공지능 로드
chst = AIchopstick()

# Volume control 준비
device = AudioUtilities.GetSpeakers()
#interface = device.Activate(IAudioEndpointVolume._iid_,CLSCTX_ALL,None)
interface = device.EndpointVolume.QueryInterface(IAudioEndpointVolume)
volume = cast(interface,POINTER(IAudioEndpointVolume))

# Mediapipe 준비
'''
mp_hands=mp.solutions.hands
hands=mp_hands.Hands(max_num_hands=1)
mp_drawing=mp.solutions.drawing_utils
'''
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    static_image_mode=False,      # 동영상 모드
    max_num_hands=1,              # 손 1개만 인식
    min_detection_confidence=0.7, # 신뢰도 70% 이상
    min_tracking_confidence=0.7
)
#'''
'''
cir_style=mp_drawing.DrawingSpec(
    color=(0,0,255), thickness=3,
    circle_radius=5 )

line_style=mp_drawing.DrawingSpec(
    color=(255,0,0), thickness=5 )
'''
def dist(x1,y1,x2,y2):
    return math.sqrt(math.pow(x1 - x2,2)) + math.sqrt(math.pow(y1 - y2,2))

# Index finger, MMiddle finger, Ring finger, Pinky finger
FingureVector = [[8,6],[12,10],[16,14],[20,18]]
# Open fingure(True), Bend finger(False)
# Thumb, Index finger, MMiddle finger, Ring finger, Pinky finger
FigureCondition = [True,True,True,True,True]
FingureGesture = [[True,True,True,True,True,"Paper(Five)","(보)실행준비"],
                  [False,True,True,True,True,"Four(Timer on)","(넷)타이머 동작"],
                  [False,True,True,True,False,"Three(Timer reset)","(셋)타이머 리셋"],
                  [False,True,True,False,False,"Scissor(Sound on)","(가위)소리켜기"],
                  [False,True,False,False,False,"One(Mute)","(하나)음소거"],
                  [False,False,False,False,False,"Rock(Memo)","(바위)레시피"],
                  [True,True,False,False,True,"Spare","(Rock and roll)네이버"],
                  [True,False,False,False,True,"Spare","(Call me)미정"],
                  [True,True,False,False,False,"Set volume","소리조절"],
                  [True,False,False,False,False,"Spare","(최고)<미정>"],
                  [False,False,False,False,True,"Spare","(약속)<미정>"]]


def MPControl(frame,width,height,activeChopstick):
    ename = ""
    name = ""
    RecogGesture = -1

    #frame=cv2.flip(frame,1)
    image=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results=hands.process(image)

    # PIL 이미지로 변환 (한글출력)
    img_pil = Image.fromarray(frame)
    draw = ImageDraw.Draw(img_pil)

    # 한글 지원 폰트를 가져옴 (나눔고딕 사용)
    unicode_font = ImageFont.truetype(font="fonts/NanumGothic.ttf", size=24)
    # 한글 폰트 컬러
    font_color = (0,0,255)#RED


    if results.multi_hand_landmarks:
        # 젓가락질 정상여부 인식 수행
        if activeChopstick:
            handlm = results.multi_hand_landmarks[0]
            # AI 분석
            features = chst.extract_features(handlm)
            chst.feature_queue.append(features)

            # 데이터가 충분히 모이면 판단
            if len(chst.feature_queue) == chst.sequence_length:
                # 데이터 변환 (큐 -> 넘파이 -> 텐서)
                seq = np.array(list(chst.feature_queue))
                seq_flat = seq.reshape(-1, seq.shape[-1])
                seq_scaled = chst.scaler.transform(seq_flat).reshape(1, chst.sequence_length, -1)
                input_tensor = torch.tensor(seq_scaled, dtype=torch.float32).to(chst.device)

                # AI 추론
                with torch.no_grad():
                    output = chst.model(input_tensor)
                    loss = nn.MSELoss()(output, input_tensor).item()

                # 색상으로 이상유무 결과출력 (빨강:불량, 초록:양호)
                if loss > chst.threshold:
                    status_color=(0,0,255)#빨강(BAD)
                    kname = "젓가락질이 바르지 않습니다!"
                else:
                    status_color=(0,255,0)#초록(GOOD)
                    kname = "젓가락질이 정상입니다!"
                # img_pil 영상 데이터에 한글 텍스트를 그려줌
                draw.text((10,10),kname,font=unicode_font,fill=status_color)
                frame = np.array(img_pil)
                # 젓가락질 정상유무를 색상으로 표시
                cir_style=mp_drawing.DrawingSpec(
                    color=status_color, thickness=3, circle_radius=5)
                line_style=mp_drawing.DrawingSpec(
                    color=status_color, thickness=5)
                mp_drawing.draw_landmarks( frame, handlm,
                    mp_hands.HAND_CONNECTIONS, cir_style, line_style )

        # 핸드제스처 인식 수행
        else:
            for handlm in results.multi_hand_landmarks:
                for i in range(0,4):# From the index figure to the pinky finger
                    FigureCondition[i+1] = dist(handlm.landmark[0].x, handlm.landmark[0].y,
                        handlm.landmark[FingureVector[i][0]].x,
                        handlm.landmark[FingureVector[i][0]].y) > dist(handlm.landmark[0].x,
                        handlm.landmark[0].y, handlm.landmark[FingureVector[i][1]].x,
                        handlm.landmark[FingureVector[i][1]].y)

                thumb_mcp_x = round(handlm.landmark[2].x * width)
                thumb_mcp_y = round(handlm.landmark[2].y * height)
                thumb_tip_x = round(handlm.landmark[4].x * width)
                thumb_tip_y = round(handlm.landmark[4].y * height)
                index_mcp_x = round(handlm.landmark[5].x * width)
                index_mcp_y = round(handlm.landmark[5].y * height)
                index_tip_x = round(handlm.landmark[8].x * width)
                index_tip_y = round(handlm.landmark[8].y * height)
                pinky_mcp_x = round(handlm.landmark[17].x * width)
                pinky_mcp_y = round(handlm.landmark[17].y * height)
                # Detecting whether a thumb is folded or not
                dist_palm = dist(index_mcp_x,index_mcp_y,pinky_mcp_x,pinky_mcp_y)
                dist_thumb = dist(thumb_tip_x,thumb_tip_y,pinky_mcp_x,pinky_mcp_y)
                if dist_palm > dist_thumb:
                    FigureCondition[0] = False
                else:
                    FigureCondition[0] = True

                numGesRecog = -1
                for i in range(0,len(FingureGesture)):
                    cntGesRecog = 0
                    for j in range(0,5):
                        if(FingureGesture[i][j] == FigureCondition[j]):
                            cntGesRecog += 1
                    if(cntGesRecog==5):
                        numGesRecog = i

                if numGesRecog > -1:
                    ename = FingureGesture[numGesRecog][5]
                    kname = FingureGesture[numGesRecog][6]
                    # img_pil 영상 데이터에 한글 텍스트를 그려줌
                    draw.text((10,10),kname,font=unicode_font,fill=font_color)
                    # OpenCV를 활용해 한글 화면 출력
                    frame = np.array(img_pil)
                    #cv2.putText(frame,FingureGesture[numGesRecog][5],(50,50),
                    #            cv2.FONT_HERSHEY_TRIPLEX,2,(255,0,0),2)

                #0(다섯), 1(넷), 2(셋), 3(둘), 4(하나), 5(주먹),
                #6(음소거), 7(소리켜기), 8(볼륨조절), 9(네이버), 10(종료)
                if numGesRecog == 0:#(다섯,보자기)프로그램 실행 준비
                    RecogGesture = 0
                elif numGesRecog == 1:#(넷)타이머 동작
                    RecogGesture = 1
                elif numGesRecog == 2:#(셋)타이머 리셋
                    RecogGesture = 2
                elif numGesRecog == 3:#(둘,가위)소리 커기(Volume on)
                    RecogGesture = 3
                    volume.SetMute(0,None)
                elif numGesRecog == 4:#(하나)소리 중지(Mute)
                    RecogGesture = 4
                    volume.SetMute(1,None)
                elif numGesRecog == 5:#(주먹)요리 레시피 열기
                    RecogGesture = 5
                elif numGesRecog == 6:#(Rock and roll)네이버
                    RecogGesture = 6
                elif numGesRecog == 7:#(Call me)<미정>
                    RecogGesture = 7
                elif numGesRecog == 8:#(집게)볼륨 조절(Set volume)
                    RecogGesture = 8
                    cv2.circle(frame,(thumb_tip_x,thumb_tip_y),30,(0,255,0),10)
                    cv2.circle(frame,(index_tip_x,index_tip_y),30,(0,255,0),10)
                    volevel = dist(thumb_tip_x,thumb_tip_y,index_tip_x,index_tip_y) / (
                                dist(thumb_mcp_x,thumb_mcp_y,index_mcp_x,index_mcp_y)*2)
                    volevel = round(volevel*100)
                    if volevel > 96:
                        volevel = 96
                    volevel = -96 + volevel
                    volume.SetMasterVolumeLevel(volevel,None)#-96(volume 0)~0(volume 100)
                elif numGesRecog == 9:#(엄지,최고)<미정>
                    RecogGesture = 9
                elif numGesRecog == 10:#(새끼,약속)<미정>
                    RecogGesture = 10

                cir_style=mp_drawing.DrawingSpec(color=(0,0,255), thickness=3, circle_radius=5)
                line_style=mp_drawing.DrawingSpec(color=(255,0,0), thickness=5)
                mp_drawing.draw_landmarks( frame, handlm,
                    mp_hands.HAND_CONNECTIONS, cir_style, line_style )

    elif activeChopstick:
        status_color=(255,0,0)#파랑(기본)
        kname = "젓가락질을 해주세요!"
        # img_pil 영상 데이터에 한글 텍스트를 그려줌
        draw.text((10,10),kname,font=unicode_font,fill=status_color)
        frame = np.array(img_pil)

    return frame, RecogGesture
