import sys
from PyQt5.QtWidgets import QApplication
from pyqtGUI import WinGUI

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = WinGUI()
    ex.show()
    sys.exit(app.exec_())