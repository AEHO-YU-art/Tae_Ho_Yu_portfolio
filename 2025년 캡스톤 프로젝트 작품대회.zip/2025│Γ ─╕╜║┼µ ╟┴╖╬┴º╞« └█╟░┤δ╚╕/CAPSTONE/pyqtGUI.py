import cv2
import time
import threading
import subprocess
import functions
from PyQt5.QtWidgets import QWidget, QLabel, QLCDNumber
from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout, QPushButton, QMessageBox
from PyQt5.QtGui import QPixmap, QFont, QIcon, QImage
from PyQt5.QtCore import QTimer, QTime

#추가 라이브러리
import sys
from PyQt5.QtWidgets import QApplication
from pyqtGUI import WinGUI


class WinGUI(QWidget):
    def __init__(self):
        super().__init__()
        # 윈도우 타이틀
        self.wintitle = '핸드제스처 인식 이동형 스마트 스카우터'
        # 윈도우 스크린 초기생성 X 좌표(pixel)
        self.left = 200
        # 윈도우 스크린 초기생성 Y 좌표(pixel)
        self.top = 100
        # 윈도우 가로 크기(pixel)
        self.width = 800
        # 윈도우 세로 크기(pixel)
        self.height = 500
        # 카메라 동작여부 플래그
        self.activeShow = False
        # 객체인식 동작여부 플래그
        self.activeRecog = False
        # 프로그램 실생여부 플래그
        self.activeTask = False
        # 핸드제스처 인식번호
        self.numHandGest = -1
        # 젓가락질 정상 인식
        self.activeChopstick = False
        self.initGUI()

    def initGUI(self):
        # 윈도우창 이름과 크기 설정 및 출력
        self.setWindowTitle(self.wintitle)
        self.setWindowIcon(QIcon('gui\polybot_icon.png'))
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.resize(800,500)

        # 초기 실행 시 레이블에 출력되는 이미지 설정
        pixmap = QPixmap('gui\polybot.png')
        self.imgLabel = QLabel()
        self.imgLabel.setPixmap(pixmap)

        # 텍스트 폰트 설정
        font = QFont('Times-Italic',24)
        font.setBold(True)
        # OpenCV 실행을 위한 버튼 생성
        btn_openCam = QPushButton("웹카메라켜기")
        btn_openCam.setStyleSheet('color:rgb(0,0,0); background:rgb(175,238,238)')
        btn_openCam.setFont(font)
        btn_closeCam = QPushButton("웹카메라끄기")
        btn_closeCam.setStyleSheet('color:rgb(0,0,0); background:rgb(175,238,238)')
        btn_closeCam.setFont(font)
        btn_openHGes = QPushButton("핸드제스처시작")
        btn_openHGes.setStyleSheet('color:rgb(0,0,0); background:rgb(255,228,225)')
        btn_openHGes.setFont(font)
        btn_closeHGes = QPushButton("핸드제스처종료")
        btn_closeHGes.setStyleSheet('color:rgb(0,0,0); background:rgb(255,228,225)')
        btn_closeHGes.setFont(font)
        btn_openChst = QPushButton("젓가락인식시작")
        btn_openChst.setStyleSheet('color:rgb(0,0,0); background:rgb(173,255,47)')
        btn_openChst.setFont(font)
        btn_closeChst = QPushButton("젓가락인식종료")
        btn_closeChst.setStyleSheet('color:rgb(0,0,0); background:rgb(173,255,47)')
        btn_closeChst.setFont(font)
        # 타이머 실행 버튼
        self.btn_StartTimer = QPushButton("시작")
        self.btn_StartTimer.setStyleSheet('color:rgb(0,0,0); background:rgb(224,224,224)')
        self.btn_StartTimer.setFont(font)
        self.btn_ClearTimer = QPushButton("리셋")
        self.btn_ClearTimer.setStyleSheet('color:rgb(0,0,0); background:rgb(224,224,224)')
        self.btn_ClearTimer.setFont(font)

        # 아래쪽 정보출력용 텍스트 라벨 생성
        self.textLabel = QLabel()
        self.textLabel.setText('안녕하세요~ 저는 인공지능 핸드제스처 인식기 입니다^^')
        self.textLabel.setStyleSheet('color:rgb(0,0,0); background:rgb(255,255,192)')
        self.font = QFont('Times-Italic',18)
        self.font.setBold(True)
        self.textLabel.setFont(font)

        # 타이머 생성
        self.txTime = QLCDNumber(self)
        self.txTime.setSegmentStyle(QLCDNumber.Flat)
        self.counting = False
        self.msInLastLaps = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.slotTimerEvent)
        self.checktimer = QTimer(self)
        self.checktimer.timeout.connect(self.CheckTime)
        self.checktimer.start(250)#0.25초 마다 호출
        self.CheckTime()

        # 왼쪽 Vertical 레이아웃 설정 맟 카메라영상 출력을 위한 라벨 추가
        LeftLayout = QVBoxLayout()
        LeftLayout.addWidget(self.imgLabel)
        # 오른쪽 Vertical 레이아웃 설정 및 버튼 추가
        RightLayout = QVBoxLayout()
        RightLayout.addWidget(btn_openCam)
        RightLayout.addWidget(btn_closeCam)
        RightLayout.addWidget(btn_openHGes)
        RightLayout.addWidget(btn_closeHGes)
        RightLayout.addWidget(btn_openChst)
        RightLayout.addWidget(btn_closeChst)
        RightLayout.addWidget(self.txTime)
        TimerLayout = QHBoxLayout()
        TimerLayout.addWidget(self.btn_StartTimer)
        TimerLayout.addWidget(self.btn_ClearTimer)
        RightLayout.addLayout(TimerLayout)

        # 아래쪽 Vertical 레이아웃 설정(텍스트 메시지 표시)
        BottomLayout = QVBoxLayout()
        BottomLayout.addWidget(self.textLabel)
        # 왼쪽과 오른쪽 Vertical 레이아웃 통합
        BothLayout = QHBoxLayout()
        BothLayout.addLayout(LeftLayout)
        BothLayout.addLayout(RightLayout)
        # 아래쪽 레이아웃 추가 통합
        FullLayout = QVBoxLayout()
        FullLayout.addLayout(BothLayout)
        FullLayout.addLayout(BottomLayout)
        # 전체 통합 레이아웃 윈도우 표시
        self.setLayout(FullLayout)

        # 버튼이 눌렸을때 실행하는 함수 연결
        btn_openCam.clicked.connect(self.openCam)
        btn_closeCam.clicked.connect(self.closeCam)
        btn_openHGes.clicked.connect(self.openHGes)
        btn_closeHGes.clicked.connect(self.closeHGes)
        btn_openChst.clicked.connect(self.openChopstick)
        btn_closeChst.clicked.connect(self.closeChopstick)
        self.btn_StartTimer.clicked.connect(self.TimerStart)
        self.btn_ClearTimer.clicked.connect(self.TimerClear)

    def CheckTime(self):
        if self.numHandGest == 0:
            self.activeTask = True
            #print('activeTask')
        elif self.numHandGest == 1 and self.activeTask:
            self.activeTask = False
            self.TimerStart()
        elif self.numHandGest == 2 and self.activeTask:
            self.activeTask = False
            self.TimerClear()
        elif self.numHandGest == 5 and self.activeTask:
            self.activeTask = False
            # 메모장 파일 열기
            #file_path = "D:\PROJECT\CAPSTONE\\utils\\recipe.txt"
            #subprocess.run(['notepad.exe',file_path],shell=True)
            # PDF 파일 열기
            file_path = "D:\PROJECT\CAPSTONE\\utils\\recipe.pdf"
            hpdf_path = "C:\Program Files (x86)\Hnc\Office 2022\HOffice120\Bin\Hpdf.exe"
            subprocess.run([hpdf_path,file_path],shell=True)
        elif self.numHandGest == 6 and self.activeTask:
            self.activeTask = False
            # 크롬으로 네이버 실행
            chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
            url = "https:\\www.naver.com"
            subprocess.run([chrome,url],shell=True)

    def openCam(self):
        if self.activeShow:
            QMessageBox.critical(self,'[ERROR]','이미 웹카메라가 켜져있습니다!!!')
        else:
            self.activeShow = True
            th = threading.Thread(target=self.threadCam)
            th.start()
            self.textLabel.setText('영상출력을 합니다!')

    def closeCam(self):
        self.activeShow = False
        self.activeRecog = False
        self.activeChopstick = False
        self.textLabel.setText('영상출력을 종료합니다!')
        # 스레드 종료까지 시간지연
        time.sleep(0.1)
        # 카메라 종료에따라 화면에 초기 실행 시 레이블에 출력되는 이미지 출력
        pixmap = QPixmap('gui\polybot.png')
        self.imgLabel.setPixmap(pixmap)

    def openHGes(self):
        if self.activeShow:
            self.activeRecog = True
            self.textLabel.setText('핸드제스처 인식을 합니다!')
        else:
            QMessageBox.critical(self,'[ERROR]','웹카메라를 먼저 켜주세요!!!')

    def closeHGes(self):
        self.activeRecog = False
        self.activeChopstick = False
        self.textLabel.setText('핸드제스처인식 종료합니다!')

    def openChopstick(self):
        if self.activeShow:
            if self.activeRecog:
                self.activeChopstick = True
                self.textLabel.setText('젓가락질 이상유무를 인식합니다!')
            else:
                QMessageBox.critical(self,'[ERROR]','핸드제스처 인식을 먼저 시작해 주세요!!!')
        else:
            QMessageBox.critical(self,'[ERROR]','웹카메라를 먼저 켜주세요!!!')

    def closeChopstick(self):
        self.activeChopstick = False
        self.textLabel.setText('핸드제스처 인식을 합니다!')


    def threadCam(self):
        # 카메라 디바이스 오픈
        cam = cv2.VideoCapture(0)
        cam.set(3,640) # set video width
        cam.set(4,480) # set video height
        #width = cam.get(cv2.CAP_PROP_FRAME_WIDTH)
        #height = cam.get(cv2.CAP_PROP_FRAME_HEIGHT)
        width = 640
        height = 480
        self.imgLabel.resize(width,height)
        # 카메라 영상 표시
        while self.activeShow:
            ret, image = cam.read()
            if ret:
                # 영상 좌우 반전 (거울모드)
                image = cv2.flip(image,1)
                # 제스처인식 함수수행
                if self.activeRecog:
                    image, self.numHandGest = functions.MPControl(image,width,height,self.activeChopstick)
                image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB) 
                height, width, channel = image.shape
                qImage = QImage(image.data,width,height,width*channel,QImage.Format_RGB888)
                pixmap = QPixmap.fromImage(qImage)
                self.imgLabel.setPixmap(pixmap)
            else:
                QMessageBox.critical(self,'[ERROR]','영상을 읽어오는데 실패했습니다!!!')
                break
        cam.release()
        self.textLabel.setText('카메라가 종료되었습니다!')

    def displayTime(self, msecs):
        ms = msecs % 1000
        msecs /= 1000
        sec = msecs % 60
        msecs /= 60
        min = msecs % 60
        msecs /= 60
        hours = msecs
        timestring = '%02d:%02d:%02d' % (hours,min,sec)
        self.txTime.setNumDigits(8 if hours > 0 else 5)
        self.txTime.display(timestring)

    def TimerStart(self):
        if ( self.counting ):
            self.timer.stop()
            self.msInLastLaps += self.startTime.msecsTo(QTime.currentTime())
            self.btn_StartTimer.setText("시작")
        else:
            self.startTime = QTime.currentTime()
            self.timer.start(500)
            self.btn_StartTimer.setText("멈춤")
            self.slotTimerEvent()
        self.counting = not self.counting

    def TimerClear(self):
        self.msInLastLaps = 0
        self.startTime = QTime.currentTime()
        self.displayTime(0)

    def slotTimerEvent(self):
        self.displayTime(self.msInLastLaps + self.startTime.msecsTo(QTime.currentTime()))

    # QWiget 종료 시 발생되는 이벤트 핸들러
    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Message', 'Are you sure to quit?',
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.checktimer.stop()
            self.displayTime(10)
            event.accept()
        else:
            event.ignore()

    def show(self):
        super().show()


#추가코드
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = WinGUI()
    ex.show()
    sys.exit(app.exec_())