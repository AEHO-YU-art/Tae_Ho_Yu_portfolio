import sys
import os
import json
import math
import time
import pickle
import collections
import numpy as np
import cv2
import torch
import torch.nn as nn
import mediapipe as mp

class GRUAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(GRUAutoencoder, self).__init__()
        # 인코더: 입력을 압축 (GRU 사용)
        self.encoder = nn.GRU(input_dim, hidden_dim, batch_first=True)
        # 디코더: 압축된 정보를 풀기
        self.decoder = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        # FC: 마지막에 데이터 크기를 원래대로 맞춰줌
        self.fc = nn.Linear(hidden_dim, input_dim)

    def forward(self, x):
        seq_len = x.shape[1] # 시간 길이 (예: 45)
        _, h_n = self.encoder(x) # 압축
        
        # 압축된 정보(h_n)를 시간 길이만큼 복사해서 디코더 입력으로 만듦
        decoder_input = h_n.repeat(seq_len, 1, 1).permute(1, 0, 2)
        
        decoded, _ = self.decoder(decoder_input) # 복원
        reconstructed = self.fc(decoded)
        return reconstructed

def calculate_angles(landmarks):
    angles = []
    # 각도를 잴 관절 번호들 (예: 1-2-3번 점을 이어서 각도 계산)
    angle_points = [
        (1, 2, 3), (2, 3, 4), (0, 5, 6), (5, 6, 7), (6, 7, 8),
        (0, 9, 10), (9, 10, 11), (10, 11, 12), (0, 13, 14), (13, 14, 15), (14, 15, 16),
        (0, 17, 18), (17, 18, 19), (18, 19, 20)
    ]
    for p1, p2, p3 in angle_points:
        v1 = landmarks[p1] - landmarks[p2] # 벡터 1
        v2 = landmarks[p3] - landmarks[p2] # 벡터 2
        
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        # 길이가 0이면(에러) 각도 0으로 처리
        if norm_v1 < 1e-6 or norm_v2 < 1e-6:
            angle = 0.0
        else:
            # 내적 공식으로 각도(라디안) 계산
            dot = np.dot(v1/norm_v1, v2/norm_v2)
            angle = np.arccos(np.clip(dot, -1.0, 1.0))
        angles.append(angle)
    return np.array(angles)

def normalize_coordinates(landmarks):
    # 손 크기가 달라도 똑같이 인식되도록 좌표를 정규화(크기조절)하는 함수
    wrist = landmarks[0] # 손목 좌표
    relative = landmarks - wrist # 손목을 원점(0,0,0)으로 이동
    
    # 손 크기(손목~중지뿌리 거리) 계산
    scale = np.linalg.norm(landmarks[9] - wrist)
    if scale < 1e-6: scale = 1.0
    
    # 크기로 나누고 1줄로 쫙 펴서 반환
    return (relative / scale).flatten()


class AIchopstick:
    def __init__(self):
        # 1. 장치 설정 (GPU 우선)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"[Init] Device: {self.device}")
        
        # 2. 설정 변수
        self.sequence_length = 45  # 45프레임(약 1.5초) 모아서 판단
        self.feature_queue = collections.deque(maxlen=self.sequence_length)
        
        self.load_resources()

    def load_resources(self):
        try:
            # 스케일러 로드
            if not os.path.exists("utils\scaler.pkl"): raise FileNotFoundError("scaler.pkl 없음!")
            with open("utils\scaler.pkl", "rb") as f: self.scaler = pickle.load(f)
            
            input_dim = self.scaler.mean_.shape[0] # 입력 데이터 크기 자동 감지
            print(f"[Load] Input dim: {input_dim}")
            
            # AI 모델 로드
            self.model = GRUAutoencoder(input_dim=input_dim, hidden_dim=128).to(self.device)
            if not os.path.exists("model\\best_loss_model.pth"): raise FileNotFoundError("모델 파일 없음")
            self.model.load_state_dict(torch.load("model\\best_loss_model.pth", map_location=self.device))
            self.model.eval() # 평가 모드 설정

            # 템플릿 파일 로드
            if not os.path.exists("utils\\angle_template.json"): 
                raise FileNotFoundError("angle_template.json 없음")
            
            with open("utils\\angle_template.json", "r", encoding='utf-8') as f:
                self.template = json.load(f)
            print("[Load] Template loaded.")

            # (4) 판단 기준값
            self.threshold = 0.5 # 몇으로 해야할지 감 안잡힘..

        except Exception as e:
            print(f"초기화 실패: {e}")
            sys.exit(1) # 프로그램 종료

    def extract_features(self, hand_landmarks):
        # 손 랜드마크에서 특징 추출
        lm_np = np.array([[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark])
        
        norm_coords = normalize_coordinates(lm_np) # 좌표 정규화
        angles = calculate_angles(lm_np)           # 각도 계산
        
        expected_dim = self.scaler.mean_.shape[0] # 목표 차원수
        
        # 차원수에 맞춰 데이터 조립
        if expected_dim == 74:
            return np.concatenate((norm_coords[3:], angles)) # 손목 제외
        elif expected_dim == 63:
            return norm_coords
        elif expected_dim == 77:
            return np.concatenate((norm_coords, angles))
        else:
            return np.concatenate((norm_coords, angles))[:expected_dim]
