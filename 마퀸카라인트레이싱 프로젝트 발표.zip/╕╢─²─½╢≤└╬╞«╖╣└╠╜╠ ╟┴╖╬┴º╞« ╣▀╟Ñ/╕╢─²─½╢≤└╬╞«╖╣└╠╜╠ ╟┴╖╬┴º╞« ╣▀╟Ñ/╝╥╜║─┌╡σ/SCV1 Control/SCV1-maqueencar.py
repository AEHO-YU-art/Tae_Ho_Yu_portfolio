from microbit import *
import radio
import machine
import time

radio.on()
radio.config(group=144)
I2C_ADDRESS = 0x10

class MC: # MotorControl
    FWD = 1
    BWD = 2
    STOP = 0

def motor(dir_l, p_l, dir_r, p_r):
    try:
        i2c.write(I2C_ADDRESS, bytearray([0x00, dir_l, p_l, dir_r, p_r]))
    except Exception as e:
        pass

LINE_REG = b'\x1D'

class LS: # LineSensor
    L3, L2, L1, R1, R2, R3 = range(6)

def get_line():
    i2c.write(I2C_ADDRESS, bytearray(LINE_REG))
    data = i2c.read(I2C_ADDRESS, 1)
    return tuple(1 if (data[0] >> i) & 0x01 else 0 for i in range(6))

BASE_P_R = 70
BASE_P_L = BASE_P_R 
TURN_S = 25 # Strong Turn Adj (no obj)
TURN_M = 19 # Medium Turn Adj (no obj)

GRIP_TURN_S = 45 # Strong Turn Adj (with obj)
GRIP_TURN_M = 32 # Medium Turn Adj (with obj)

route_cmds = ""
cmd_idx = 0
exec_route = False

class ServoPort:
    S1 = 0x14
    @staticmethod
    def list():
        return [ServoPort.S1]

class Servo:
    def __init__(self, id):
        if id not in ServoPort.list():
            raise ValueError("Invalid Servo: " + str(id))
        self.id = id
    def rotateTo(self, angle: int) -> None:
        try:
            i2c.write(I2C_ADDRESS, bytearray([self.id, angle]))
        except Exception as e:
            pass

def read_us(trig, echo, max_dist):
    trig.write_digital(1)
    time.sleep_us(10)
    trig.write_digital(0)
    pulse_time = machine.time_pulse_us(echo, 1, max_dist * 5830)
    return (pulse_time / 2) * 343 / 10000

def get_dist(trig=pin14, echo=pin15, max_dist=5):
    trig.write_digital(0)
    echo.read_digital()
    return round(read_us(trig, echo, max_dist))

servo_1 = Servo(ServoPort.S1)
GRIP_OPEN = 50
GRIP_CLOSE = 160

has_obj = False
last_dists = []

def update_gripper():
    global has_obj, last_dists
    current_dist = get_dist()
    last_dists.append(current_dist)
    if len(last_dists) > 5:
        last_dists.pop(0)    # 리스트의 길이가 5보다 커지면 (즉, 6개의 데이터가 되면), 맨 앞에 있는 요소(가장 오래전에 측정된 거리)를 제거 ->이 과정을 통해 last_dists 리스트는 항상 최근 5개의 거리 측정값만 유지하기 위함.

    if has_obj:
        if any(d > 15 for d in last_dists):
            servo_1.rotateTo(GRIP_OPEN)
            display.show(Image.HAPPY)
            has_obj = False
            sleep(500)
        return

    if all(d <= 10 for d in last_dists) and not has_obj:
        servo_1.rotateTo(GRIP_CLOSE)
        display.show(Image.SAD)
        has_obj = True
        sleep(500)
    else:
        servo_1.rotateTo(GRIP_OPEN)
        display.show(Image.HAPPY)


def apply_line_tracing(dir_L, dir_R, base_L, base_R):
    global has_obj
    lines = get_line()

    curr_base_L, curr_base_R = base_L, base_R
    curr_turn_s, curr_turn_m = TURN_S, TURN_M

    if has_obj:
        curr_turn_s = GRIP_TURN_S
        curr_turn_m = GRIP_TURN_M

    # FWD 모드에서 교차로 감지 로직
    if dir_L == MC.FWD and dir_R == MC.FWD:
        if all(lines[i] == 1 for i in [LS.L2, LS.L1, LS.R1, LS.R2]):
            motor(MC.STOP, 0, MC.STOP, 0)
            display.show(Image.SQUARE)
            sleep(50)
            motor(MC.FWD, 30, MC.FWD, 30) # 교차로 통과를 위한 전진
            sleep(300)
            motor(MC.STOP, 0, MC.STOP, 0)
            sleep(50)
            return True

    # 라인 트레이싱 회전 보정 로직
    # 이 값을 조절하여 반대편 모터를 얼마나 가속할지 결정합니다. (0.0 ~ 1.0)
    # 0.0이면 기존 로직(한쪽 모터만 감속), 1.0이면 제자리 회전에 가까움.
    # 0.3에서 0.7 사이의 값으로 시작하여 테스트해보세요.
    TURN_ACCEL_FACTOR = 0.7 

    if lines[LS.L3] == 1 or lines[LS.L2] == 1: # 왼쪽 센서 감지 (강하게 우회전)
        # 왼쪽 바퀴는 감속, 오른쪽 바퀴는 가속하여 우회전 강도를 높임
        motor(dir_L, curr_base_L - curr_turn_s, dir_R, min(curr_base_R + int(curr_turn_s * TURN_ACCEL_FACTOR), 100))
    elif lines[LS.R3] == 1 or lines[LS.R2] == 1: # 오른쪽 센서 감지 (강하게 좌회전)
        # 오른쪽 바퀴는 감속, 왼쪽 바퀴는 가속하여 좌회전 강도를 높임
        motor(dir_L, min(curr_base_L + int(curr_turn_s * TURN_ACCEL_FACTOR), 100), dir_R, curr_base_R - curr_turn_s)
    elif lines[LS.L1] == 1: # 왼쪽 안쪽 센서 감지 (약하게 우회전)
        # 왼쪽 바퀴는 감속, 오른쪽 바퀴는 가속하여 우회전 강도를 높임
        motor(dir_L, curr_base_L - curr_turn_m, dir_R, min(curr_base_R + int(curr_turn_m * TURN_ACCEL_FACTOR), 100))
    elif lines[LS.R1] == 1: # 오른쪽 안쪽 센서 감지 (약하게 좌회전)
        # 오른쪽 바퀴는 감속, 왼쪽 바퀴는 가속하여 좌회전 강도를 높임
        motor(dir_L, min(curr_base_L + int(curr_turn_m * TURN_ACCEL_FACTOR), 100), dir_R, curr_base_R - curr_turn_m)
    else: # 라인 중앙 또는 벗어남 -> 직진/직후진
        motor(dir_L, curr_base_L, dir_R, curr_base_R)
    return False


def do_forward():
    global exec_route
    display.show("F")
    while exec_route:
        update_gripper()
        if apply_line_tracing(MC.FWD, MC.FWD, BASE_P_L, BASE_P_R):
            break
        sleep(10)

def do_turn_180():
    global exec_route, has_obj
    display.show("T")
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(100)
    
    if has_obj:
                display.show(Image.CONFUSED)
                motor(MC.STOP, 0, MC.STOP, 0)
                sleep(100)
                servo_1.rotateTo(GRIP_OPEN)
                has_obj = False
                display.show(Image.ASLEEP)
                sleep(1000)
    
    while exec_route:
        lines = get_line()
        if not (lines[LS.L2] == 0 or lines[LS.R2] == 0):
            
            break
        motor(MC.BWD, BASE_P_L, MC.BWD, BASE_P_R)
        sleep(10)

    motor(MC.BWD, 50, MC.BWD, 50)
    sleep(300)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(100)

    while exec_route:
        if get_line()[LS.L2] == 1:
            break
        motor(MC.BWD, 50, MC.FWD, 45)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(100)

    while exec_route:
        if (get_line()[LS.L1]== 1  and get_line()[LS.R1]== 1) :
            break
        motor(MC.BWD, 20, MC.FWD, 35)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(100)


def do_turn_180_2():
    global exec_route
    display.show("t")
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(100)

    motor(MC.FWD, 30, MC.FWD, 30)
    start_time = running_time() # 1. 현재 시간(시작 시간) 기록
    while exec_route:
        lines = get_line()
        if lines[LS.L2] == 0 or lines[LS.R2] == 0:
            break
        if running_time() - start_time > 2000: # 2. 현재 시간 - 시작 시간이 2000ms(2초)를 초과하면
            break  # 3. 루프를 강제로 빠져나옴 (타임아웃) 
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)

    turn_power_l = 60
    turn_power_r = 50

    # L2 감지까지 왼쪽 제자리 회전
    while exec_route:
        if get_line()[LS.L2] == 1: break
        motor(MC.BWD, turn_power_l, MC.FWD, turn_power_r)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)

    # L1 감지까지 왼쪽 제자리 회전
    while exec_route:
        if get_line()[LS.L1] == 1: break
        motor(MC.BWD, turn_power_l, MC.FWD, turn_power_r)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)
    
    # L2 흰색 감지까지 왼쪽 제자리 회전
    while exec_route:
        if get_line()[LS.L2] == 0: break
        motor(MC.BWD, turn_power_l, MC.FWD, turn_power_r)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)

    # L2 검은색 감지까지 왼쪽 제자리 회전
    while exec_route:
        if get_line()[LS.L2] == 1: break
        motor(MC.BWD, turn_power_l, MC.FWD, turn_power_r)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)

    # L1, R1 감지까지 왼쪽 제자리 회전
    while exec_route:
        lines = get_line()
        if (lines[LS.L1] == 1 or lines[LS.R1] == 1):
            motor(MC.BWD, 40, MC.FWD, 30)
            sleep(100)
            break
        motor(MC.BWD, turn_power_l, MC.FWD, turn_power_r)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)
    '''
    # L3, R3 흰색 감지까지 전진
    while exec_route:
        lines = get_line()
        if (lines[LS.L3] == 0 and lines[LS.R3] == 0):
            motor(MC.FWD, 30, MC.FWD, 30)
            sleep(100)
            break
        motor(MC.FWD, 60, MC.FWD, 50)
        sleep(10)
    motor(MC.STOP, 0, MC.STOP, 0)
    sleep(50)
    '''

    


cmd_map = {
    'F': do_forward,
    'T': do_turn_180,
    't': do_turn_180_2
}

display.show(Image.ASLEEP)
servo_1.rotateTo(GRIP_OPEN)

while True:
    msg = radio.receive()
    if msg == "btn_A":
        exec_route = True
        route_cmds = "FTFt"
        cmd_idx = 0
        display.show(Image.ARROW_N)
        sleep(300)

    if exec_route:
        if cmd_idx < len(route_cmds):
            cmd_char = route_cmds[cmd_idx]
            if cmd_char in cmd_map:
                display.show(cmd_char)
                cmd_map[cmd_char]()
                cmd_idx += 1
            else:    # cmd_char와 cmd_map의 문자 부분이 F T t 이런 똑같은 문자 임으로 이 else 부분이 의미없어 보일 수 있으나 누군가 실수로  route_cmds = "FTFt"에서 F T t 이외의 문자를 넣어 오류낼 수 있어서
                display.show(Image.NO)         # 그런 오류를 대비하여 이 else를 넣어 다른 문자를 넣었다면 바로 정지 시켜버리는 로직을 추가한 것임.
                exec_route = False
                motor(MC.STOP, 0, MC.STOP, 0)   
        else:
            display.show(Image.HAPPY)
            motor(MC.STOP, 0, MC.STOP, 0)
            exec_route = False
            route_cmds = ""
            has_obj = False
            servo_1.rotateTo(GRIP_OPEN)
    else:
        motor(MC.STOP, 0, MC.STOP, 0)
        update_gripper()
        sleep(100)