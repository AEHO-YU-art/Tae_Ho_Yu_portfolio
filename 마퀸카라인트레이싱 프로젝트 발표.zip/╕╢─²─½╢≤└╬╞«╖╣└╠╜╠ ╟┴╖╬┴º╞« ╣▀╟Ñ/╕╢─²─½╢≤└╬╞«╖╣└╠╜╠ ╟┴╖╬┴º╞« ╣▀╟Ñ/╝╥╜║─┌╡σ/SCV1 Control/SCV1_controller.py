from microbit import *
import music # 사용되지 않으므로 제거 가능 (필요 없으면 삭제해도 됩니다)
import radio

radio.on()
radio.config(group = 144)

# 풀업 저항 설정: 버튼이 눌리지 않았을 때 HIGH, 눌렸을 때 LOW (0)
pin8.set_pull(pin8.PULL_UP) #Z버튼
pin13.set_pull(pin13.PULL_UP) #C버튼
pin14.set_pull(pin14.PULL_UP) #D버튼
pin15.set_pull(pin15.PULL_UP) #E버튼
pin16.set_pull(pin16.PULL_UP) #F버튼

while True:
    # 이 컨트롤러에서는 메시지를 받을 필요가 없으므로 rx_msg는 불필요하지만,
    # 코드의 흐름상 큰 문제 없으니 유지합니다.
    rx_msg = radio.receive() 
    X = pin1.read_analog()   # 조이스틱 X축 값 읽기
    Y = pin2.read_analog()   # 조이스틱 Y축 값 읽기

    # A 버튼: 기존 라인 트레이싱 토글
    if button_a.is_pressed():
        radio.send('btn_A')
        display.show("A")
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)
    # pin16 버튼: 자동 경로 탐색 시작/정지 토글
    # pin16이 눌리면 read_digital()은 0을 반환하므로 not 0은 True가 됩니다.
    '''
    elif not pin16.read_digital(): 
        radio.send("start_route_16")
        display.show("F") # 16 버튼이 눌렸음을 표시
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)
    # 다른 버튼 (Z, C, D, E)에 대한 로직도 필요하다면 여기에 추가할 수 있습니다.
    # 예:
    # elif not pin8.read_digital():
    #     radio.send('btn_Z')
    #     display.show("Z")
    #     sleep(300)

    
    elif not pin15.read_digital(): 
        radio.send("start_route_15")
        display.show("E") # 16 버튼이 눌렸음을 표시
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)


    elif not pin13.read_digital(): 
        radio.send("start_route_13")
        display.show("C") # 14 버튼이 눌렸음을 표시
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)

    elif not pin14.read_digital(): 
        radio.send("start_route_14")
        display.show("D") # 14 버튼이 눌렸음을 표시
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)


    elif not pin8.read_digital(): 
        radio.send("start_route_8")
        display.show("Z") # 14 버튼이 눌렸음을 표시
        sleep(300) # 버튼 중복 인식을 막기 위한 짧은 대기 (조절 가능)
    '''


    
    
    else:
        display.clear() # 아무 버튼도 눌리지 않았을 때는 화면을 끔


    

    
    
    # 불필요한 빠른 반복을 방지하기 위한 최소한의 대기
    # 모든 if/elif 조건에 해당하지 않을 때도 잠시 대기하여 CPU 부하를 줄입니다.
    sleep(10)