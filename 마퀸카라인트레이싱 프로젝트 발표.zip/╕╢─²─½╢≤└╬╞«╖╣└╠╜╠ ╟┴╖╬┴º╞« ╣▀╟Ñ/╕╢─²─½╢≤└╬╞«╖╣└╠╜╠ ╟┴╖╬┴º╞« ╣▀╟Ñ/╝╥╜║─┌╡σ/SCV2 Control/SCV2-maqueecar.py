from microbit import *
import radio
import machine
import time

radio.on()
radio.config(group=2)

# --- 모터 제어 관련 설정 ---
I2C_ADDRESS = 0x10
FWD = 1
BWD = 2
STOP = 0
HPW = 110 # High Power

def motor(dir_l, power_l, dir_r, power_r):
    try:
        i2c.write(I2C_ADDRESS, bytearray([0x00, dir_l, power_l, dir_r, power_r]))
    except OSError:
        pass

# --- 라인 센서 관련 설정 ---
LINE_STATE_REGISTER = b'\x1D'
L3, L2, L1, R1, R2, R3 = 0, 1, 2, 3, 4, 5 # 센서 인덱스

def getAllLine():
    i2c.write(I2C_ADDRESS, bytearray(LINE_STATE_REGISTER))
    data = i2c.read(I2C_ADDRESS, 1)[0]
    return tuple(1 if (data >> i) & 0x01 else 0 for i in range(6))

# --- 라인 트레이싱 및 경로 제어 설정 ---

# 기본 전진 파워 (물건 안 집었을 때)
BASE_POWER_FWD_L = HPW - 33
BASE_POWER_FWD_R = HPW

# 물건 집었을 때 전진 파워 (조절 필요)
GRIPPED_POWER_FWD_L = HPW - 20 # 예시 값: 물건 집으면 약간 더 강하게
GRIPPED_POWER_FWD_R = HPW + 10 # 예시 값: 물건 집으면 약간 더 강하게

# 후진 파워 (물건 안 집었을 때)
BASE_POWER_BWD_R = 40
BASE_POWER_BWD_L = BASE_POWER_BWD_R - int(43 * (BASE_POWER_BWD_R / HPW))

# 물건 집었을 때 후진 파워 (조절 필요)
GRIPPED_BASE_POWER_BWD_R = 50
GRIPPED_BASE_POWER_BWD_L = GRIPPED_BASE_POWER_BWD_R - int(43 * (GRIPPED_BASE_POWER_BWD_R / HPW))

# 라인 트레이싱 시 회전 보정 값 (물건 안 집었을 때)
TURN_ADJUST_STRONG_NORMAL = 80
TURN_ADJUST_MEDIUM_NORMAL = 50

# 라인 트레이싱 시 회전 보정 값 (물건 집었을 때) (조절 필요)
TURN_ADJUST_STRONG_GRIPPED = 80
TURN_ADJUST_MEDIUM_GRIPPED = 50


# 제자리 회전 파워 (물건 안 집었을 때)
NORMAL_TURN_L_BWD_PWR = 50 # 좌회전 시 왼쪽 후진
NORMAL_TURN_L_FWD_PWR = 70 # 좌회전 시 오른쪽 전진

NORMAL_TURN_R_FWD_PWR = 50 # 우회전 시 왼쪽 전진
NORMAL_TURN_R_BWD_PWR = 80 # 우회전 시 오른쪽 후진

NORMAL_TURN_180_L_BWD_PWR = 50 # T턴 시 왼쪽 후진
NORMAL_TURN_180_R_FWD_PWR = 70 # T턴 시 오른쪽 전진

NORMAL_TURN_t2_BWD_PWR_L = 40 # t턴 시 왼쪽 후진
NORMAL_TURN_t2_FWD_PWR_R = 60 # t턴 시 오른쪽 전진


# 제자리 회전 파워 (물건 집었을 때) (조절 필요)
GRIPPED_TURN_L_BWD_PWR = 55 # 물건 집었을 때 좌회전 왼쪽 후진
GRIPPED_TURN_L_FWD_PWR = 75 # 물건 집었을 때 좌회전 오른쪽 전진

GRIPPED_TURN_R_FWD_PWR = 55 # 물건 집었을 때 우회전 왼쪽 전진
GRIPPED_TURN_R_BWD_PWR = 85 # 물건 집었을 때 우회전 오른쪽 후진

GRIPPED_TURN_180_L_BWD_PWR = 60 # 물건 집었을 때 T턴 왼쪽 후진
GRIPPED_TURN_180_R_FWD_PWR = 80 # 물건 집었을 때 T턴 오른쪽 전진

GRIPPED_TURN_t2_BWD_PWR_L = 55 # 물건 집었을 때 t턴 왼쪽 후진
GRIPPED_TURN_t2_FWD_PWR_R = 75 # 물건 집었을 때 t턴 오른쪽 전진

# 물건을 집었을 때 턴 진입 전진 시간 (조절 필요)
GRIPPED_FORWARD_SLEEP_MS_LEFT_TURN = 150  # 예시: 물건 집고 좌회전 진입 시 전진 시간
GRIPPED_FORWARD_SLEEP_MS_RIGHT_TURN = 100 # 예시: 물건 집고 우회전 진입 시 전진 시간


current_route_commands = ""
current_command_index = 0
is_executing_route = False

# --- 서보 및 초음파 센서 설정 ---
SERVO_1_PORT = 0x14 # 집게 서보 포트

def set_gripper_angle(angle: int) -> None:
    try:
        # 서보 포트와 각도만 보냅니다.
        i2c.write(I2C_ADDRESS, bytearray([SERVO_1_PORT, angle]))
    except OSError:
        pass

def getDistanceUltrasonic(trig=pin14, echo=pin15, max_distance=5):
    trig.write_digital(0)
    echo.read_digital()
    trig.write_digital(1)
    time.sleep_us(10)
    trig.write_digital(0)
    pulse_time = machine.time_pulse_us(echo, 1, max_distance * 5830)
    return round(pulse_time / 58) if pulse_time > 0 else 999

# --- 집게 관련 변수 및 초기화 ---
GRIPPER_OPEN_ANGLE = 50
GRIPPER_CLOSE_ANGLE = 170

has_object = False
last_distances = [999] * 5 # 초기 값으로 999 (먼 거리)를 채워 시작

# 물건 감지 및 집게 동작을 제어하는 함수
def check_and_grip_object():
    global has_object, last_distances
    current_dist = getDistanceUltrasonic()
    last_distances.pop(0)
    last_distances.append(current_dist)

    # 물건을 잡고 있지 않을 때만 감지하고 집게 동작
    if not has_object and all(d <= 10 for d in last_distances):
        set_gripper_angle(GRIPPER_CLOSE_ANGLE)
        display.show(Image.SAD)
        has_object = True
        sleep(500)
    # 물건을 잡고 있지 않을 때만 집게를 열어둠
    elif not has_object:
        set_gripper_angle(GRIPPER_OPEN_ANGLE)
        display.show(Image.HAPPY)


# --- 헬퍼 함수: 라인 트레이싱 로직 ---
# 전진 라인 트레이싱 전용
def apply_line_tracing_fwd(is_first_f_mode=False):
    line_sensors = getAllLine()

    # 물건 유무에 따라 라인 트레이싱 보정 값 선택
    turn_adjust_strong = TURN_ADJUST_STRONG_GRIPPED if has_object else TURN_ADJUST_STRONG_NORMAL
    turn_adjust_medium = TURN_ADJUST_MEDIUM_GRIPPED if has_object else TURN_ADJUST_MEDIUM_NORMAL
    
    # 물건 유무에 따라 기본 전진 파워 선택
    current_base_L = GRIPPED_POWER_FWD_L if has_object else BASE_POWER_FWD_L
    current_base_R = GRIPPED_POWER_FWD_R if has_object else BASE_POWER_FWD_R

    # 교차로 감지 (L2, L1, R1, R2 모두 검은색)
    # 첫 F 모드에서는 교차로 정지 로직도 무시
    if all(line_sensors[i] == 1 for i in [L2, L1, R1, R2]) and not is_first_f_mode:
        motor(STOP, STOP, STOP, STOP)
        display.show(Image.SQUARE)
        sleep(50)
        motor(FWD, 30, FWD, 30) # 교차로 정지 후 미세 전진 파워는 고정
        sleep(300)
        motor(STOP, STOP, STOP, STOP)
        sleep(50)
        return True # 교차로 도착 및 정지

    # 라인 트레이싱 로직
    if is_first_f_mode: # 첫 F 모드일 경우 L3, R3는 고려하지 않음 (물건 집는 F)
        if line_sensors[L2]:
            motor(FWD, current_base_L - turn_adjust_medium, FWD, current_base_R)
        elif line_sensors[R2]:
            motor(FWD, current_base_L, FWD, current_base_R - turn_adjust_medium)
        elif line_sensors[L1]:
            motor(FWD, current_base_L - turn_adjust_medium, FWD, current_base_R)
        elif line_sensors[R1]:
            motor(FWD, current_base_L, FWD, current_base_R - turn_adjust_medium)
        else: # 라인 중앙 또는 벗어남 -> 직진
            motor(FWD, current_base_L, FWD, current_base_R - 10) # 10은 직진 보정
    else: # 일반 라인 트레이싱 모드 (L3, R3 포함)
        if line_sensors[L3] or line_sensors[L2]:
            motor(FWD, current_base_L - turn_adjust_strong, FWD, current_base_R)
        elif line_sensors[R3] or line_sensors[R2]:
            motor(FWD, current_base_L, FWD, current_base_R - turn_adjust_strong)
        elif line_sensors[L1]:
            motor(FWD, current_base_L - turn_adjust_medium, FWD, current_base_R)
        elif line_sensors[R1]:
            motor(FWD, current_base_L, FWD, current_base_R - turn_adjust_medium)
        else: # 라인 중앙 또는 벗어남 -> 직진
            motor(FWD, current_base_L, FWD, current_base_R)

    return False

# --- 함수 정의: 각 동작 (F, L, R, T, B) ---

def do_forward():
    global is_executing_route
    display.show("F")

    is_first_command_F = (current_command_index == 0 and current_route_commands.startswith('F'))

    while is_executing_route:
        if is_first_command_F:
            check_and_grip_object()
            if has_object:
                motor(STOP, STOP, STOP, STOP)
                sleep(50)
                break
        
        if apply_line_tracing_fwd(is_first_f_mode=is_first_command_F):
            break
        
        sleep(10)


def do_left_right_turn_common(turn_char, turn_dir_l, turn_power_l, turn_dir_r, turn_power_r,
                               outer_sensor_idx, inner_sensor_idx, align_motor_l_dir, align_motor_r_dir, forward_sleep_ms=100):
    global is_executing_route
    display.show(turn_char)
    motor(STOP, STOP, STOP, STOP)
    sleep(100)

    # 1. 십자 교차 정중앙까지 살짝 전진 (여기서도 물건 유무에 따라 전진 파워와 시간 조정 가능)
    # 현재는 고정 40이지만, 필요시 GRIPPED_FORWARD_POWER_FOR_TURN_ENTRY 등을 정의하여 사용
    motor(FWD, 40, FWD, 40)
    sleep(forward_sleep_ms) 
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    
    # 2. 바깥 센서 감지까지 제자리 회전
    while is_executing_route and not getAllLine()[outer_sensor_idx]:
        motor(turn_dir_l, turn_power_l, turn_dir_r, turn_power_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 3. 안쪽 센서 감지까지 제자리 회전
    while is_executing_route and not getAllLine()[inner_sensor_idx]:
        motor(turn_dir_l, turn_power_l, turn_dir_r, turn_power_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 4. 라인 중앙에 정렬될 때까지 미세 조정 (L1 or R1 감지)
    # 정렬 시 파워도 물건 유무에 따라 조절할 수 있습니다. (현재는 고정 30, 60)
    align_pwr_l = 30
    align_pwr_r = 60
    # if has_object:
    #     align_pwr_l = GRIPPED_ALIGN_POWER_L
    #     align_pwr_r = GRIPPED_ALIGN_POWER_R
    
    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L1] or line_sensors[R1]) and not (line_sensors[L2] or line_sensors[R2]):
            break
        motor(align_motor_l_dir, align_pwr_l, align_motor_r_dir, align_pwr_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 5. 다음 교차로 진입을 위해 전진
    do_forward()

def do_left_turn():
    # 물건 유무에 따른 좌회전 파워 선택
    current_turn_l_bwd_pwr = GRIPPED_TURN_L_BWD_PWR if has_object else NORMAL_TURN_L_BWD_PWR
    current_turn_l_fwd_pwr = GRIPPED_TURN_L_FWD_PWR if has_object else NORMAL_TURN_L_FWD_PWR
    
    # 물건 유무에 따른 전진 시간 선택: has_object가 True면 GRIPPED_FORWARD_SLEEP_MS_LEFT_TURN, 아니면 기존값(50)
    current_forward_sleep_ms = GRIPPED_FORWARD_SLEEP_MS_LEFT_TURN if has_object else 50 
    
    do_left_right_turn_common("L", BWD, current_turn_l_bwd_pwr, FWD, current_turn_l_fwd_pwr, L3, L2, BWD, FWD, forward_sleep_ms=current_forward_sleep_ms)

def do_right_turn():
    # 물건 유무에 따른 우회전 파워 선택
    current_turn_r_fwd_pwr = GRIPPED_TURN_R_FWD_PWR if has_object else NORMAL_TURN_R_FWD_PWR
    current_turn_r_bwd_pwr = GRIPPED_TURN_R_BWD_PWR if has_object else NORMAL_TURN_R_BWD_PWR
    
    # 물건 유무에 따른 전진 시간 선택: has_object가 True면 GRIPPED_FORWARD_SLEEP_MS_RIGHT_TURN, 아니면 기존값(100)
    current_forward_sleep_ms = GRIPPED_FORWARD_SLEEP_MS_RIGHT_TURN if has_object else 100 
    
    do_left_right_turn_common("R", FWD, current_turn_r_fwd_pwr, BWD, current_turn_r_bwd_pwr, R3, R2, FWD, BWD, forward_sleep_ms=current_forward_sleep_ms)

def do_turn_180():
    global is_executing_route, has_object
    display.show("T")
    motor(STOP, STOP, STOP, STOP)
    sleep(100)

    # 물건 소지 여부에 따라 후진 파워 선택
    current_base_bwd_r = GRIPPED_BASE_POWER_BWD_R if has_object else BASE_POWER_BWD_R
    current_base_bwd_l = GRIPPED_BASE_POWER_BWD_L if has_object else BASE_POWER_BWD_R - int(43 * (current_base_bwd_r / HPW))

    # T 턴을 위한 후진
    while is_executing_route:
        line_sensors = getAllLine()
        if line_sensors[L2] == 0 and line_sensors[R2] == 0:
            break
        motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
        sleep(10)
    
    # 물건을 잡고 있을 때만 물건을 내려놓는 로직 수행
    if has_object:
       
        motor(STOP, STOP, STOP, STOP)
        display.show(Image.CONFUSED)
        sleep(200)
        set_gripper_angle(GRIPPER_OPEN_ANGLE)
        motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
        sleep(450) # 물건을 정확히 내려놓기 위한 추가 후진 (조절 필요)
        has_object = False
        display.show(Image.ASLEEP)
        sleep(1000)
    else: # 물건이 없다면, 일반적인 T 턴 후진 시간 적용
        motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
        sleep(450) # 기존 T 턴 후진 시간
        motor(STOP, STOP, STOP, STOP)
        sleep(100)

    # 180도 턴 회전 로직 (물건을 내려놓았으므로 has_object는 이제 False. 일반 턴 파워 사용)
    # T 턴 파워 선택 (물건 내려놓았으므로 일반 값 사용)
    turn_power_l = NORMAL_TURN_180_L_BWD_PWR
    turn_power_r = NORMAL_TURN_180_R_FWD_PWR

    while is_executing_route:
        if getAllLine()[L2] == 1:
            break
        motor(BWD, turn_power_l, FWD, turn_power_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L1] == 1 or line_sensors[R1] == 1) and \
           (line_sensors[L2] == 0 and line_sensors[R2] == 0):
            break

        motor(BWD, turn_power_l, FWD, turn_power_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

def do_turn_180_2():
    global is_executing_route
    display.show("t")
    motor(STOP, STOP, STOP, STOP)
    sleep(100)
    
    # 물건 소지 여부에 따라 't' 턴 회전 파워 결정
    current_turn_power_bwd_l = GRIPPED_TURN_t2_BWD_PWR_L if has_object else NORMAL_TURN_t2_BWD_PWR_L
    current_turn_power_fwd_r = GRIPPED_TURN_t2_FWD_PWR_R if has_object else NORMAL_TURN_t2_FWD_PWR_R

    #L3와 R3가 검은색 감지 될때까지 후진
    motor(BWD, 50, BWD, 50) # 이 부분은 물건 유무와 관계없이 고정 후진
    start_time = running_time()
    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L3] == 1) or (line_sensors[R3] == 1): #반듯하게 일자로 L3와 R3가 감지 안 될 수 있고 사선으로 L3나 R3 둘 중 하나가 감지 될 수 있어서
            break
        if running_time() - start_time > 2000:
            break
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    #L3와 R3가 밝은색 감지 될때까지 전진
    motor(FWD, 50, FWD, 50) # 이 부분은 물건 유무와 관계없이 고정 전진
    start_time = running_time()
    while is_executing_route:
        line_sensors = getAllLine()
        if line_sensors[L3] == 0 and line_sensors[R3] == 0:
            motor(FWD, 50, FWD, 50)
            sleep(100)
            break
        if running_time() - start_time > 2000:
            break
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 턴 파워 적용 (L3 감지까지)
    while is_executing_route:
        if getAllLine()[L3] == 1:
            break
        motor(BWD, current_turn_power_bwd_l, FWD, current_turn_power_fwd_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 턴 파워 적용 (L2 감지까지)
    while is_executing_route:
        if getAllLine()[L2] == 1:
            break
        motor(BWD, current_turn_power_bwd_l, FWD, current_turn_power_fwd_r)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)
    
    # 턴 파워 적용 (L2 흰색 감지까지) - 이 부분은 고정 파워 (정렬에 가까움)
    while is_executing_route:
        if getAllLine()[L2] == 0:
            break
        motor(BWD, 50, FWD, 70)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 턴 파워 적용 (L2 검은색 감지까지) - 이 부분은 고정 파워 (정렬에 가까움)
    while is_executing_route:
        if getAllLine()[L2] == 1:
            break
        motor(BWD, 50, FWD, 70)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 라인 중앙 정렬 (물건 유무와 관계없이 동일하게 유지)
    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L1] == 1 and line_sensors[R1] == 1):
            break
        motor(BWD, 30, FWD, 60)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

    # 마지막 정렬 전진 (물건 유무와 관계없이 동일하게 유지)
    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L3] == 0 and line_sensors[R3] == 0):
            motor(FWD, 30, FWD, 30)
            sleep(100)
            break
        motor(FWD, 50, FWD, 50)
        sleep(10)
    motor(STOP, STOP, STOP, STOP)
    sleep(50)

def do_backward():
    global is_executing_route, has_object
    display.show("B")
    motor(STOP, STOP, STOP, STOP)
    sleep(100)

    # 물건 소지 여부에 따라 후진 모터 파워 선택
    current_base_bwd_l = GRIPPED_BASE_POWER_BWD_L if has_object else BASE_POWER_BWD_L
    current_base_bwd_r = GRIPPED_BASE_POWER_BWD_R if has_object else BASE_POWER_BWD_R

    while is_executing_route:
        line_sensors = getAllLine()
        if all(line_sensors[i] == 1 for i in [L2, L1, R1, R2]):
            motor(STOP, STOP, STOP, STOP)
            display.show(Image.ASLEEP)
            sleep(50)
            break
        
        motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
        sleep(10)
    
    while is_executing_route:
        line_sensors = getAllLine()
        if (line_sensors[L2] == 0 and line_sensors[R2] == 0 and
            line_sensors[L1] == 1 and line_sensors[R1] == 1):
            motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
            sleep(200)
            motor(STOP, STOP, STOP, STOP)
            display.show(Image.ASLEEP)
            sleep(50)
            break
        
        motor(BWD, current_base_bwd_l, BWD, current_base_bwd_r)
        sleep(10)
    

# --- 경로 실행 맵핑 ---
command_map = {
    'F': do_forward,
    'L': do_left_turn,
    'R': do_right_turn,
    'T': do_turn_180,
    'B': do_backward,
    't': do_turn_180_2
}

# --- 메인 루프 ---
display.show(Image.ASLEEP)
SERVO_1_PORT = 0x14

class Servo:
    def __init__(self, port_address):
        self.port_address = port_address
    def rotateTo(self, angle):
        try:
            i2c.write(I2C_ADDRESS, bytearray([self.port_address, angle]))
        except OSError:
            pass

servo_1 = Servo(SERVO_1_PORT)
# 초기 집게 상태 설정 (항상 열린 상태)
servo_1.rotateTo(GRIPPER_OPEN_ANGLE)

while True:
    rx_msg = radio.receive()

    if rx_msg:
        route_mapping = {
            "start_route_16": "FtFLFRTFLFRB", #내용연수 경과제품
            "start_route_15": "FtFLRTFLRB",  #사용용도 전환제품
            "start_route_13": "FtFFTFFB",  #재활용 가능성제품
            "start_route_14": "FtFRLTFRLB",  #부품 추출제품
            "start_route_8":  "FtFRFLTFRFLB", # 폐기
        }
        if rx_msg in route_mapping:
            is_executing_route = True
            current_route_commands = route_mapping[rx_msg]
            current_command_index = 0
            has_object = False # 새로운 경로 시작 시 물건 소지 상태 초기화
            display.show(Image.ARROW_N)
            sleep(300)
    
    if is_executing_route:
        if current_command_index < len(current_route_commands):
            command_char = current_route_commands[current_command_index]
            if command_char in command_map:
                display.show(command_char)
                command_map[command_char]() # 해당 명령 함수 실행
                current_command_index += 1
            else:
                display.show(Image.NO)
                is_executing_route = False
                motor(STOP, STOP, STOP, STOP)
        else:
            display.show(Image.HAPPY)
            motor(STOP, STOP, STOP, STOP)
            is_executing_route = False
            current_route_commands = ""
            has_object = False # 경로 완료 시 물건 소지 상태 초기화
            servo_1.rotateTo(GRIPPER_OPEN_ANGLE) # 경로 완료 시 집게 열기
    else:
        motor(STOP, STOP, STOP, STOP)
        set_gripper_angle(GRIPPER_OPEN_ANGLE)
        display.show(Image.HAPPY)
        sleep(100)